//Documentation of the methods are in the method

public class Grid {
	public static Square[][] grid = new Square[Main.gameWidth][Main.gameHeight + 2];
}