//keeps track of level and time left in game
//keeps track of current game stats

public class Levels {
	public static int level = 9;
}
